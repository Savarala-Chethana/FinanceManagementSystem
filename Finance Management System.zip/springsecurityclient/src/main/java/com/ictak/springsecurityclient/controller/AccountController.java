package com.ictak.springsecurityclient.controller;


import com.ictak.springsecurityclient.entity.Account;
import com.ictak.springsecurityclient.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/accounts")
public class AccountController {

    @Autowired
    private AccountService accountService;
    @PostMapping(" ")
    public Account saveAccounts(@RequestBody Account account){
        return accountService.saveAccount(account);
    }
    @GetMapping("/{id}")
    public Account getAccountById(@PathVariable("id") Long accountId){
        return accountService.getAccountById(accountId);
    }
    @GetMapping("/all")
    public List getAllAccounts(){
        return accountService.getAllAccount();
    }
    @PutMapping("/{id}")
    public Account updateAccounts(@PathVariable("id") Long accountId,@RequestBody Account account) {
        return accountService.updateAccount(accountId, account);
    }

    @DeleteMapping("/{id}")
    public void deleteAccountById(@PathVariable("id") Long accountId) {
        accountService.deleteAccountById(accountId);
    }
}
