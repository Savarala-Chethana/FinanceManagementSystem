package com.ictak.springsecurityclient.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;

@Entity
@Table(name="account")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Account implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="account_id")
    private Long accountId;
    @Column(name="account_type")
    private String accountType;
    @Column(name="balance")
    private double balance;
    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;


}