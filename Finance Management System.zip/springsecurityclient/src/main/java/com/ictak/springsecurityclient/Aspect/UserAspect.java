package com.ictak.springsecurityclient.Aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class UserAspect {


    @After("execution(* authenticate(..))")
    public void afterSaveContact() {
        System.out.println("Login successfully");
    }
    @After("execution(* registeruser(..))")
    public void afterUpdateContact() {
        System.out.println("Registered successfully");
    }
}
