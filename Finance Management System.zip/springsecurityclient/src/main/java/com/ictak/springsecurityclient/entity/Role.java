package com.ictak.springsecurityclient.entity;

public enum Role {
	ADMIN,
	USER
}
