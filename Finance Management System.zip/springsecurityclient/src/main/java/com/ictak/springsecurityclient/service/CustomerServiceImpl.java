package com.ictak.springsecurityclient.service;


import com.ictak.springsecurityclient.entity.Customer;
import com.ictak.springsecurityclient.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service

public class CustomerServiceImpl implements CustomerService {
    @Autowired
    private CustomerRepository customerRepository;
    @Override
    public Customer saveCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

    @Override
    public Customer getCustomerById(Long customerId) {
        return customerRepository.findById(customerId).get();
    }

    @Override
    public Customer updateCustomer(Long customerId, Customer customer) {
        Customer custDB = customerRepository.findById(customerId).get();

        if (Objects.nonNull(customer.getCustomerName()) && !"".equalsIgnoreCase(customer.getCustomerName()))
            custDB.setCustomerName(customer.getCustomerName());

        if (Objects.nonNull(customer.getCustomerAddress()) && !"".equalsIgnoreCase(customer.getCustomerAddress()))
            custDB.setCustomerAddress(customer.getCustomerAddress());

        if (Objects.nonNull(customer.getPhoneNumber()) && !"".equalsIgnoreCase(customer.getPhoneNumber()))
            custDB.setPhoneNumber(customer.getPhoneNumber());

        return customerRepository.save(custDB);

    }

    @Override
    public void deleteCustomerById(Long customerId) {
        customerRepository.deleteById(customerId);
    }


    public List getAllCustomer() {
        return customerRepository.findAll();
    }
}
