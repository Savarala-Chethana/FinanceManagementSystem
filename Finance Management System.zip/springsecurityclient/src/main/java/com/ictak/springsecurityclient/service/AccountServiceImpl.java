package com.ictak.springsecurityclient.service;


import com.ictak.springsecurityclient.entity.Account;
import com.ictak.springsecurityclient.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
public class AccountServiceImpl implements AccountService {
    @Autowired
    private AccountRepository accountRepository;
    @Override
    public Account saveAccount(Account account) {
        return accountRepository.save(account);
    }

    @Override
    public Account getAccountById(Long accountId) {
        return accountRepository.findById(accountId).get();
    }

    @Override
    public Account updateAccount(Long accountId, Account account) {
        Account accountDB = accountRepository.findById(accountId).get();

        if (Objects.nonNull(account.getAccountType()) && !"".equalsIgnoreCase(account.getAccountType()))
            accountDB.setAccountType(account.getAccountType());

        return accountRepository.save(accountDB);

    }

    @Override
    public void deleteAccountById(Long accountId) {
        accountRepository.deleteById(accountId);
    }


    public List getAllAccount() {
        return accountRepository.findAll();
    }
}
