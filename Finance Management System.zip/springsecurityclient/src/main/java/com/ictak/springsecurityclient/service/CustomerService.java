package com.ictak.springsecurityclient.service;

import com.ictak.springsecurityclient.entity.Customer;

import java.util.List;

public interface CustomerService {
    Customer saveCustomer(Customer customer);

    Customer getCustomerById(Long customerId);

    Customer updateCustomer(Long customerId, Customer customer);

    void deleteCustomerById(Long customerId);

    List getAllCustomer();
}
