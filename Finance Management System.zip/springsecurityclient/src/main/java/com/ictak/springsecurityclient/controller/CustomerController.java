package com.ictak.springsecurityclient.controller;


import com.ictak.springsecurityclient.entity.Customer;
import com.ictak.springsecurityclient.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;
    @PostMapping(" ")
    public Customer saveCustomers(@RequestBody Customer customer){
        return customerService.saveCustomer(customer);
    }

    @GetMapping("/{id}")
    public Customer getCustomersById(@PathVariable("id") Long customerId){
        return customerService.getCustomerById(customerId);
    }
    @GetMapping("/all")
    public List getAllCustomers(){

        return customerService.getAllCustomer();
    }

    @PutMapping("/{id}")
    public Customer updateCustomers(@PathVariable("id") Long customerId,@RequestBody Customer customer) {
        return customerService.updateCustomer(customerId, customer);
    }

    @DeleteMapping("/{id}")
    public void deleteCustomersById(@PathVariable("id") Long customerId) {
        customerService.deleteCustomerById(customerId);
    }
}
