package com.ictak.springsecurityclient.service;

import com.ictak.springsecurityclient.entity.Account;

import java.util.List;

public interface AccountService {
    Account saveAccount(Account account);

    Account getAccountById(Long accountId);

    Account updateAccount(Long accountId, Account account);

    void deleteAccountById(Long accountId);

    List getAllAccount();
}
